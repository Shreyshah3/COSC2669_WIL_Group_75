# WIL Project – Test-Driven RAG

## Walert Baseline Reproduction

This repository documents the reproduction and quantitative evaluation of the Walert
conversational RAG baseline used as the starting point for the WIL project.

### Contributor

- **Name:** Dhrumil
- **Student ID:** _Add your RMIT student ID_

## Objective

Evaluate retrieval and generation performance by comparing the original Walert
intent-based approach with BM25 and Dense FAISS retrieval combined with Falcon generation.

## Systems Evaluated

1. Walert Intent baseline
2. BM25 + Falcon
3. Dense FAISS + Falcon

## Retrieval Evaluation

| System | nDCG@1 | nDCG@3 | nDCG@5 |
|---|---:|---:|---:|
| Walert Intent | 0.0833 | 0.0391 | 0.0391 |
| BM25 | 0.1667 | 0.2566 | 0.3291 |
| Dense FAISS | 0.2500 | 0.2380 | 0.2380 |

## Generation Evaluation

The generation evaluation used BERTScore F1, BLEU, ROUGE-L F1, ROUGE-1 F1 and ROUGE-2 F1.

The detailed evaluation outputs are stored in `results/`.

## Main Findings

- Dense FAISS achieved the strongest Top-1 retrieval performance with nDCG@1 = 0.2500.
- BM25 achieved stronger multi-result retrieval performance, with nDCG@3 = 0.2566 and nDCG@5 = 0.3291.
- The original Walert intent-based system achieved substantially higher generation scores than both Falcon-based RAG approaches.
- Using Top-3 retrieved passages generally improved Falcon generation performance compared with Top-1.

## Key Interpretation

The results demonstrate that stronger retrieval performance does not automatically produce better
end-to-end answer quality. Retrieval and generation should therefore be evaluated separately
when assessing a RAG system.

## Project Status

### Completed
- Walert repository reproduced
- Walert dataset and relevance information identified
- BM25 retrieval evaluated
- Dense FAISS retrieval evaluated
- Retrieval metrics calculated
- Falcon generation evaluation outputs analysed
- Baseline results documented

### Next Stage
Use the baseline findings to define the limitations, test cases and proposed improvement
for the Test-Driven RAG project.
