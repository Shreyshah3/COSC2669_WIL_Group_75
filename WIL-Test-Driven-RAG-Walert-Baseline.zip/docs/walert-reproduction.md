# Walert Baseline Reproduction

## Contributor

- **Name:** Dhrumil
- **Student ID:** _Add your RMIT student ID_

## 1. Purpose

The Walert system was reproduced as a baseline for the WIL Test-Driven RAG project.
The purpose was to understand the existing retrieval and generation pipeline and establish
quantitative baseline results before designing an improved system.

## 2. Systems Compared

The evaluation compares:

- **Walert Intent baseline**
- **BM25 + Falcon**
- **Dense FAISS + Falcon**

## 3. Retrieval Evaluation

Retrieval quality was evaluated using nDCG at three retrieval depths:

- nDCG@1
- nDCG@3
- nDCG@5

### Results

| System | nDCG@1 | nDCG@3 | nDCG@5 |
|---|---:|---:|---:|
| Walert Intent | 0.0833 | 0.0391 | 0.0391 |
| BM25 | 0.1667 | 0.2566 | 0.3291 |
| Dense FAISS | 0.2500 | 0.2380 | 0.2380 |

### Observation

Dense FAISS performed best when only the first retrieved result was considered.
BM25 performed better at Top-3 and Top-5, indicating stronger multi-result retrieval
performance in this evaluation.

## 4. Generation Evaluation

Generated responses were evaluated using:

- BERTScore F1
- BLEU
- ROUGE-L F1
- ROUGE-1 F1
- ROUGE-2 F1

### Walert Intent Baseline

| Metric | Score |
|---|---:|
| BERTScore F1 | 0.7302 |
| BLEU | 0.5863 |
| ROUGE-L F1 | 0.6140 |
| ROUGE-1 F1 | 0.6152 |
| ROUGE-2 F1 | 0.5862 |

### BM25 + Falcon

| Retrieval depth | BERTScore F1 | BLEU | ROUGE-L F1 | ROUGE-1 F1 | ROUGE-2 F1 |
|---|---:|---:|---:|---:|---:|
| Top-1 | 0.5195 | 0.0160 | 0.1596 | 0.1761 | 0.0424 |
| Top-3 | 0.5256 | 0.0511 | 0.2010 | 0.2010 | 0.0781 |
| Top-5 | 0.5256 | 0.0511 | 0.1863 | 0.2010 | 0.0781 |

### Dense FAISS + Falcon

| Retrieval depth | BERTScore F1 | BLEU | ROUGE-L F1 | ROUGE-1 F1 | ROUGE-2 F1 |
|---|---:|---:|---:|---:|---:|
| Top-1 | 0.5220 | 0.0126 | 0.1630 | 0.1790 | 0.0436 |
| Top-3 | 0.5389 | 0.0339 | 0.2135 | 0.2135 | 0.0725 |
| Top-5 | 0.5389 | 0.0339 | 0.1928 | 0.2135 | 0.0725 |

## 5. Main Findings

1. Dense FAISS achieved the highest Top-1 retrieval score.
2. BM25 achieved stronger retrieval performance at Top-3 and Top-5.
3. The original Walert intent-based system achieved substantially higher generation
   scores than the Falcon-based RAG configurations.
4. Moving from Top-1 to Top-3 generally improved Falcon generation scores.

## 6. Key Interpretation

The experiment shows that retrieval quality and generation quality are separate components
of RAG performance. A retrieval method can retrieve more relevant documents without
necessarily producing better final answers. In this experiment, Dense FAISS was strongest
for Top-1 retrieval, BM25 was stronger at larger retrieval depths, while the original
Walert intent-based system produced the strongest generated-answer similarity.

## 7. Current Project Status

The Walert reproduction and quantitative baseline evaluation are complete. The next stage
is to use these observations to define the baseline limitations, test cases and proposed
improvement for the WIL Test-Driven RAG project.

## 8. Evidence

Detailed evaluation files are stored in the `results/` directory. The concise numerical
summary is stored in `baseline/final_metrics.txt`.
